package com.fliperama.blastmanbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlastManBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
